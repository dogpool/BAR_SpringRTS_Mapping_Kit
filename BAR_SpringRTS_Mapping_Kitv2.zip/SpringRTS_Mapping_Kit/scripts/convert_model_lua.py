# Python script to convert SpringBoard model.lua to set.lua
